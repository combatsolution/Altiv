export { default as Auth0LoginView } from './auth0-login-view';
