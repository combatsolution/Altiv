// import { Helmet } from "react-helmet-async";
// import SubHeader from "src/components/subheader/subheader";
// import { ResumeView } from 'src/sections/resume/View';



// export default function ProileViewPage(){
//     return(
//         <>
//             <Helmet>
//                 <title>Resume</title>
//             </Helmet>
//             <SubHeader subtitle="Resumes" />
//            <ResumeView />
           
//         </>
//     )
// }