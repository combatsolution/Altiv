export * from './config-lang';

export { default as useLocales } from './use-locales';
